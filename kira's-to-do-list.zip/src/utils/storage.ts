import { Task } from '../types/todo';

const STORAGE_KEY = 'kiras_to_do_list_tasks_v2';

export const SAMPLE_TASKS: Task[] = [
  {
    id: 'sample-task-1',
    title: 'Style outfit moodboard for weekend meetup',
    description: 'Match silver accessories, oversized knit, and chunky leather boots.',
    completed: false,
    priority: 'high',
    category: 'fits',
    dueDate: new Date().toISOString().split('T')[0],
    dueTime: '15:30',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    tags: ['fits', 'aesthetic', 'weekend'],
    subtasks: [
      { id: 'st-1-1', title: 'Pick out chunky silver rings & choker', completed: true },
      { id: 'st-1-2', title: 'Iron pleated charcoal skirt', completed: false },
      { id: 'st-1-3', title: 'Find vintage shoulder bag', completed: false },
    ],
    estimatedMinutes: 45,
  },
  {
    id: 'sample-task-2',
    title: 'Review design critique & layout prototypes',
    description: 'Check typography hierarchy, spacing system, and responsive breakpoints.',
    completed: false,
    priority: 'urgent',
    category: 'work',
    dueDate: new Date().toISOString().split('T')[0],
    dueTime: '18:00',
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    tags: ['work', 'design', 'urgent'],
    subtasks: [
      { id: 'st-2-1', title: 'Review hero typography', completed: true },
      { id: 'st-2-2', title: 'Check mobile menu drawer animation', completed: true },
      { id: 'st-2-3', title: 'Export Figma icons and clover assets', completed: false },
    ],
    estimatedMinutes: 60,
  },
  {
    id: 'sample-task-3',
    title: 'Morning matcha latte & 15m stretch',
    description: 'Oat milk matcha with lavender syrup and gentle mindful breathing.',
    completed: true,
    completedAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    priority: 'medium',
    category: 'wellness',
    dueDate: new Date().toISOString().split('T')[0],
    dueTime: '09:00',
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    tags: ['routine', 'wellness'],
    subtasks: [],
    estimatedMinutes: 20,
  },
  {
    id: 'sample-task-4',
    title: 'Pick up dry cleaning & refill film camera roll',
    description: '35mm Portra 400 film and silk blouse from local cleaners.',
    completed: false,
    priority: 'low',
    category: 'errands',
    dueDate: new Date(Date.now() - 86400000).toISOString().split('T')[0], // Overdue
    dueTime: '14:00',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    tags: ['errands', 'camera'],
    subtasks: [
      { id: 'st-4-1', title: 'Locate dry clean receipt ticket', completed: true },
      { id: 'st-4-2', title: 'Stop by camera lab on 4th st', completed: false },
    ],
    estimatedMinutes: 30,
  },
  {
    id: 'sample-task-5',
    title: 'Organize study playlist & journal entries',
    description: 'Curate ambient lo-fi tracklist and reflect on weekly creative goals.',
    completed: false,
    priority: 'medium',
    category: 'personal',
    dueDate: new Date(Date.now() + 86400000).toISOString().split('T')[0], // Tomorrow
    dueTime: '20:00',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    tags: ['journal', 'personal'],
    subtasks: [],
    estimatedMinutes: 40,
  },
];

export function loadTasksFromStorage(): Task[] {
  if (typeof window === 'undefined') return SAMPLE_TASKS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return SAMPLE_TASKS;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return SAMPLE_TASKS;
  } catch (err) {
    console.error('Failed to parse tasks from storage:', err);
    return SAMPLE_TASKS;
  }
}

export function saveTasksToStorage(tasks: Task[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch (err) {
    console.error('Failed to save tasks to storage:', err);
  }
}

export function exportTasksToJSON(tasks: Task[]): void {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(tasks, null, 2));
  const downloadAnchor = document.createElement('a');
  const dateStr = new Date().toISOString().split('T')[0];
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', `kira-tasks-${dateStr}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function importTasksFromJSON(file: File): Promise<Task[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        if (!Array.isArray(parsed)) {
          throw new Error('Imported JSON must be an array of tasks.');
        }
        resolve(parsed);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file.'));
    reader.readAsText(file);
  });
}
