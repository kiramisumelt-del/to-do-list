import { Task, AppNotification } from '../types/todo';

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getNotificationPermission(): NotificationPermission {
  if (!isNotificationSupported()) return 'denied';
  return Notification.permission;
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNotificationSupported()) return false;
  try {
    const result = await Notification.requestPermission();
    return result === 'granted';
  } catch {
    return false;
  }
}

export function sendBrowserNotification(title: string, options?: NotificationOptions): boolean {
  if (!isNotificationSupported() || Notification.permission !== 'granted') {
    return false;
  }
  try {
    new Notification(title, {
      icon: '/src/assets/images/mascot_bunny_avatar_1791959065082.jpg',
      badge: '/src/assets/images/mascot_bunny_avatar_1791959065082.jpg',
      ...options,
    });
    return true;
  } catch (err) {
    console.warn('Browser notification failed to trigger', err);
    return false;
  }
}

export function getLocalDateString(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function generateTaskNotifications(tasks: Task[]): AppNotification[] {
  const todayStr = getLocalDateString(new Date());
  const notifications: AppNotification[] = [];

  tasks.forEach((task) => {
    // Only active (uncompleted) tasks should be in active to-do notifications
    if (task.completed) return;

    const taskDate = task.dueDate ? task.dueDate.split('T')[0] : '';

    if (taskDate && taskDate < todayStr) {
      notifications.push({
        id: `notif-overdue-${task.id}`,
        taskId: task.id,
        taskTitle: task.title,
        type: 'overdue',
        date: taskDate,
        read: false,
        priority: task.priority,
        dueTime: task.dueTime,
        category: task.category,
      });
    } else if (taskDate === todayStr) {
      notifications.push({
        id: `notif-today-${task.id}`,
        taskId: task.id,
        taskTitle: task.title,
        type: 'due_today',
        date: taskDate,
        read: false,
        priority: task.priority,
        dueTime: task.dueTime,
        category: task.category,
      });
    }
  });

  return notifications;
}
