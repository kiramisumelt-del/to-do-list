interface CloverIconProps {
  className?: string;
}

export function CloverIcon({ className = "w-4 h-4" }: CloverIconProps) {
  return (
    <svg 
      viewBox="0 0 100 100" 
      fill="currentColor" 
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* 4 clover lobes meeting in center just like user image reference */}
      {/* Top petal */}
      <path d="M 50 48 C 42 34 32 16 50 8 C 68 16 58 34 50 48 Z" />
      {/* Right petal */}
      <path d="M 52 50 C 66 42 84 32 92 50 C 84 68 66 58 52 50 Z" />
      {/* Bottom petal */}
      <path d="M 50 52 C 58 66 68 84 50 92 C 32 84 42 66 50 52 Z" />
      {/* Left petal */}
      <path d="M 48 50 C 34 58 16 68 8 50 C 16 32 34 42 48 50 Z" />
    </svg>
  );
}
