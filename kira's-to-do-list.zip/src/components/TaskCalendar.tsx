import { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon
} from 'lucide-react';
import { Task } from '../types/todo';
import { CloverIcon } from './CloverIcon';

interface TaskCalendarProps {
  tasks: Task[];
  onToggleComplete?: (id: string) => void;
  onEdit?: (task: Task) => void;
  onDelete?: (id: string) => void;
  onToggleSubtask?: (taskId: string, subtaskId: string) => void;
  onAddTaskForDate?: (dateStr: string) => void;
}

export function TaskCalendar({
  tasks,
  onAddTaskForDate,
}: TaskCalendarProps) {
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDateStr, setSelectedDateStr] = useState<string>(todayStr);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];

  const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0 = Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const prevMonthDays = Array.from({ length: firstDayOfMonth }, (_, i) => {
    return daysInPrevMonth - firstDayOfMonth + i + 1;
  });

  const currentMonthDays = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const totalCells = prevMonthDays.length + currentMonthDays.length;
  const nextMonthDaysCount = totalCells % 7 === 0 ? 0 : 7 - (totalCells % 7);
  const nextMonthDays = Array.from({ length: nextMonthDaysCount }, (_, i) => i + 1);

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const handleJumpToday = () => {
    const now = new Date();
    setCurrentDate(now);
    setSelectedDateStr(todayStr);
  };

  const formatDateStr = (y: number, m: number, d: number) => {
    const mm = String(m + 1).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    return `${y}-${mm}-${dd}`;
  };

  // Group active tasks by date
  const tasksByDate = tasks.reduce((acc, t) => {
    if (!t.completed && t.dueDate) {
      acc[t.dueDate] = acc[t.dueDate] || [];
      acc[t.dueDate].push(t);
    }
    return acc;
  }, {} as Record<string, Task[]>);

  return (
    <section className="bg-[#FBF9F2] rounded-3xl border border-[#DDD6EC] p-5 sm:p-7 shadow-sm">
      {/* Calendar Header with Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 pb-4 border-b border-[#DDD6EC]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#FFFFFF] border border-[#DDD6EC] flex items-center justify-center text-[#2E2741] shadow-2xs">
            <CalendarIcon className="h-5 w-5 text-[#3B607A]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display font-bold text-xl text-[#2E2741]">
                {monthNames[month]} {year}
              </h3>
              <CloverIcon className="w-4 h-4 text-[#D9E4EC]" />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleJumpToday}
            className="px-3 py-1.5 rounded-xl bg-[#FFFFFF] hover:bg-[#EDE9F6] border border-[#DDD6EC] text-xs font-mono font-semibold text-[#2E2741] transition-colors cursor-pointer shadow-2xs"
          >
            Today
          </button>
          <div className="flex items-center gap-1 bg-[#FFFFFF] rounded-xl border border-[#DDD6EC] p-0.5 shadow-2xs">
            <button
              onClick={handlePrevMonth}
              title="Previous month"
              className="p-1.5 rounded-lg text-[#766E87] hover:text-[#2E2741] hover:bg-[#EDE9F6] transition-colors cursor-pointer"
              aria-label="Previous month"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={handleNextMonth}
              title="Next month"
              className="p-1.5 rounded-lg text-[#766E87] hover:text-[#2E2741] hover:bg-[#EDE9F6] transition-colors cursor-pointer"
              aria-label="Next month"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Weekday Labels */}
      <div className="grid grid-cols-7 gap-1 sm:gap-2 mb-2 text-center text-[11px] font-mono font-bold text-[#766E87] uppercase tracking-wider">
        <span>Sun</span>
        <span>Mon</span>
        <span>Tue</span>
        <span>Wed</span>
        <span>Thu</span>
        <span>Fri</span>
        <span>Sat</span>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1 sm:gap-2">
        {/* Previous Month Days */}
        {prevMonthDays.map((d, i) => (
          <div
            key={`prev-${i}`}
            className="min-h-[58px] sm:min-h-[72px] p-1.5 sm:p-2 rounded-2xl bg-[#F6F3EC]/50 border border-transparent text-[#B8ADC9] text-xs select-none"
          >
            <span className="font-mono text-[11px]">{d}</span>
          </div>
        ))}

        {/* Current Month Days */}
        {currentMonthDays.map((d) => {
          const dateStr = formatDateStr(year, month, d);
          const isToday = dateStr === todayStr;
          const isSelected = dateStr === selectedDateStr;
          const dayTasks = tasksByDate[dateStr] || [];

          return (
            <button
              key={`curr-${d}`}
              onClick={() => setSelectedDateStr(dateStr)}
              className={`min-h-[58px] sm:min-h-[72px] p-1.5 sm:p-2 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer relative group ${
                isSelected
                  ? 'bg-[#E7D1DA] border-[#D9BFCC] shadow-xs scale-[1.02]'
                  : isToday
                  ? 'bg-[#D9E4EC]/70 border-[#B8CAD8] hover:border-[#606362]/40'
                  : 'bg-[#FFFFFF] border-[#DDD6EC] hover:border-[#606362]/30 hover:bg-[#FAF7F2]'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span
                  className={`text-xs font-mono font-bold ${
                    isSelected
                      ? 'text-[#2E2741]'
                      : isToday
                      ? 'text-[#2E2741]'
                      : 'text-[#606362]'
                  }`}
                >
                  {d}
                </span>

                {isToday && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#3B607A]" />
                )}
              </div>

              {/* Task Dots / Badges */}
              <div className="w-full space-y-1 mt-1">
                {dayTasks.slice(0, 2).map((t) => (
                  <div
                    key={t.id}
                    className="truncate text-[10px] px-1 py-0.5 rounded-md bg-[#FAF7F2] border border-[#DDD6EC] text-[#2E2741] font-sans font-medium"
                  >
                    {t.title}
                  </div>
                ))}
                {dayTasks.length > 2 && (
                  <span className="text-[9px] font-mono text-[#766E87] block leading-none">
                    +{dayTasks.length - 2} more
                  </span>
                )}
              </div>
            </button>
          );
        })}

        {/* Next Month Days */}
        {nextMonthDays.map((d, i) => (
          <div
            key={`next-${i}`}
            className="min-h-[58px] sm:min-h-[72px] p-1.5 sm:p-2 rounded-2xl bg-[#F6F3EC]/50 border border-transparent text-[#B8ADC9] text-xs select-none"
          >
            <span className="font-mono text-[11px]">{d}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
